package es.uned.lsi.eped.pract2022_2023;

/* Representa un nodo raíz */
public class NodeRoot extends Node {

	public NodeRoot() {}
	
	public NodeType getNodeType() {
		return Node.NodeType.ROOT;
	}

}
