package es.uned.lsi.eped.pract2022_2023;

import ...

public class StockTree implements StockIF {

	protected GTreeIF<Node> stock; /* El stock es un árbol general de nodos */
	
	/* Constructor de la clase */
	public StockTree() {
		...
	}

	...
	
}
