package es.uned.lsi.eped.pract2022_2023;

import ...

public class StockSequence implements StockIF {

	protected SequenceIF<StockPair> stock;
	
	/* Constructor de la clase */
	public StockSequence() {
		...
	}

	...

}
